# Desafio---El-sistema-Solar
Desafío - El sistema solar


● Para realizar este desafío debes haber estudiado previamente todo el material
disponibilizado correspondiente a la unidad.

● Una vez terminado el desafío, comprime la carpeta que contiene el desarrollo de los
requerimientos solicitados y sube el .zip en el LMS.

● Desarrollo desafío:

○ El desafío se debe desarrollar de manera Individual


Descripción

Utilizando maven se requiere crear una aplicación que represente el sistema solar, donde se
deberá mostrar la relación existente entre planetas y lunas que se alojarán en un sistema solar.
Debe basarse en la información real proporcionada en la parte de recursos. Cada elemento de
la aplicación tendrá su propia Interfaz de métodos y estas se inyectarán en la clase de sistema
solar.


Requerimientos

1. Generar las clases Planeta y Luna con sus respectivas interfaces (IPlaneta e ILuna),
agregando atributos y sus respectivos getters, setters y toString relacionados a cada
clase (Luna: nombre, diámetro y tiempo de órbita. Planeta: Nombre, tamaño, distancia al
sol y lunas). Debe inyectar la clase Luna en Planeta con ayuda de ArrayList <Luna>.

2. Se deberán crear pruebas unitarias con la dependencia de Junit relacionando a los
planetas y sus lunas, debe probar: las cantidades de Lunas por planeta (utilice
assertEquals), los nombre de planetas, sus lunas ingresadas correctamente (utilice
assertTrue) y comprobar que las cantidades de lunas (utilice assertTrue). No es
necesario que pruebe con cada planeta, solo utilice el que más le guste, pero debe tener
al menos cuatro pruebas diferentes.

3. Se requiere hacer que el sistema solar funcione, genere la clase del sistema solar
llamada SistemaSolar donde inyecte los planetas apoyándose por un
ArrayList<Planeta>, desde aquí genere dos métodos, el primero debe mostrar la
información de los planetas y el segundo deber mostrar la información de los planetas y
de sus respectivas lunas. Apóyese del método toString en ambos casos.

4. Debe inyectar la clase Luna en Planeta con ayuda de ArrayList <Luna> y agregar usando
Junit las pruebas unitarias de las cantidades de Lunas por planeta (utilice assertEquals).
(Opcional)


Recursos

● Junit: https://junit.org/junit5/docs/current/user-guide/
Cantidades de lunas por planetas:

● Mercurio: Ninguna.

● Venus: Ninguna.

● Tierra: 1.

● Marte: 2.

● Júpiter: Crear solo 2 de las 79

● Saturno: Crear solo 2 de las 82

● Urano: Crear solo 2 de las 27

● Neptuno: Crear solo 2 de las 14


Información de las Lunas:

● https://www.windows2universe.org/our_solar_system/moons_table.html&lang=sp
Información de los Planetas:

● https://www.infolaso.com/tamano-de-los-planetas.html


Formato de Salida

La clase Planeta y la clase Luna, tienen un método toString, que deberán listar la información de
la siguiente manera.


Ejemplo:

Planeta: La Tierra está a 149600000 km del sol, su tamaño es de 12756 km de diámetro y tiene
1 luna, Luna de nombre Luna que mide 3476 km de diámetro y el tiempo de órbita es de 27322.0
días.

(Se muestra en el ejemplo, que la línea 1 posee el toString del planeta, mientras que en la línea 2
posee el toString de la Luna).