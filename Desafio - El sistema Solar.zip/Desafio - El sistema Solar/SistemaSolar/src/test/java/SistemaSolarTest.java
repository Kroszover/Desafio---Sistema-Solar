import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.sistema.solar.clases.Luna;
import com.sistema.solar.clases.Planeta;
import com.sistema.solar.clases.SistemaSolar;

/**
 * 
 */

/**
 * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 *
 */
public class SistemaSolarTest {
	
	SistemaSolar sistemaSolar;
	ArrayList <Planeta> planetas;
	Planeta planeta;
	Luna luna1;
	Luna luna2;



	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		sistemaSolar= new SistemaSolar();
		planetas = new ArrayList<Planeta>();
		
		planeta = new Planeta ("Marte", 6794, 227940000);
		luna1 = new Luna("Phobos", 28*20, 0.319f);
		luna2 = new Luna("Deimos", 8, 1263);
		
		planeta.addLuna(luna1);
		planeta.addLuna(luna2);
		planetas.add(planeta);
		sistemaSolar.setPlanetas(planetas);
		
		
	}


	@Test
	public void comprobarCantidadLunasPorPlaneta() {
		assertEquals(2, sistemaSolar.getPlanetas().get(0).getLunas().size());
	}
	
	@Test
	public void comprobarNombreDePlaneta() {
		assertTrue("Saturno".equals(sistemaSolar.getPlanetas().get(0).getNombre()));
	}
	
	@Test
	public void comprobarNombreDeLuna() {
		assertTrue("Deimos".equals(sistemaSolar.getPlanetas().get(0).getLunas().get(0).getNombre()));
	}
	
	@Test
	public void comprobarCantidadPlanetas() {
		assertEquals(1, sistemaSolar.getPlanetas().size());
	}

}
