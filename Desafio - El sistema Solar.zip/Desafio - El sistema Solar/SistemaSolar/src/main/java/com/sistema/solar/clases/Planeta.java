package com.sistema.solar.clases;

import java.util.ArrayList;

import com.sistema.solar.interfaces.IPlaneta;


/*
 *  * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 * */
public class Planeta implements IPlaneta{
	
	/*
	 * 1. Generar las clases Planeta y Luna con sus respectivas interfaces (IPlaneta e ILuna),
agregando atributos y sus respectivos getters, setters y toString relacionados a cada
clase (Luna: nombre, di�metro y tiempo de �rbita. Planeta: Nombre, tama�o, distancia al
sol y lunas). Debe inyectar la clase Luna en Planeta con ayuda de ArrayList <Luna>.*/
	private String Nombre;
	private float Tamanio;
	private float SunDistance;
	//ArrayList Luna
	 ArrayList<Luna> Lunas = new ArrayList<Luna>();
	 
	 //Constructores
	public Planeta() {
		// TODO Auto-generated constructor stub
	}
	public Planeta(String nombre, float tamanio, float sunDistance, ArrayList<Luna> lunas) {
		super();
		this.Nombre = nombre;
		this.Tamanio = tamanio;
		this.SunDistance = sunDistance;
		this.Lunas = lunas;
	}
	public Planeta(String nombre, float tamanio, float sunDistance) {
		super();
		this.Nombre = nombre;
		this.Tamanio = tamanio;
		this.SunDistance = sunDistance;
		
	}
	
	//Getters y Setters
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public float getTamanio() {
		return Tamanio;
	}
	public void setTamanio(float tamanio) {
		Tamanio = tamanio;
	}
	public float getSunDistance() {
		return SunDistance;
	}
	public void setSunDistance(float sunDistance) {
		SunDistance = sunDistance;
	}
	public ArrayList<Luna> getLunas() {
		return Lunas;
	}
	public void setLunas(ArrayList<Luna> lunas) {
		Lunas = lunas;
	}
	
	public void addLuna(Luna luna) {
		Lunas.add(luna);
	}
	
	private String lunaOlunas() {
		if(getLunas().size()==1) {
			return "luna";
		}
		return "lunas";
	}
	
	@Override
	public String toString() {
		return "El Planeta "+ getNombre() + " est� a " + getSunDistance() + " kms. del sol, su tama�o es de " + getTamanio() + " kms. de di�metro y tiene " + getLunas().size() + " " + lunaOlunas();
	}
	
}
	
	
	
	
	
	 
	 
	
	
	
	


