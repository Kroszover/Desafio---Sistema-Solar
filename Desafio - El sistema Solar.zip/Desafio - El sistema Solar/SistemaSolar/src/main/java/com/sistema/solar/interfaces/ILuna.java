/**
 * 
 */
package com.sistema.solar.interfaces;

/**
 *  * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 */
public interface ILuna {

}
