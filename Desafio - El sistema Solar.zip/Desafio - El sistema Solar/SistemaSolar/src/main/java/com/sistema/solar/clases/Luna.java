package com.sistema.solar.clases;

import com.sistema.solar.interfaces.ILuna;


/*
 *  * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 * */
public class Luna implements ILuna{
	private String Nombre;
	private float Diametro;
	private float TiempOrbita;
	
	//Constructor vacio.
	public Luna() {
	}
	
	//Constructor con atributos.
	public Luna(String nombre, float diametro, float tiempOrbita) {
		super();
		this.Nombre = nombre;
		this.Diametro = diametro;
		this.TiempOrbita = tiempOrbita;
	}


	//Gettter y Setters.
	public String getNombre() {
		return Nombre;
	}
	

	public void setNombre(String nombre) {
		this.Nombre = nombre;
	}
	public float getDiametro() {
		return Diametro;
	}
	public void setDiametro(float diametro) {
		this.Diametro = diametro;
	}
	public float getTiempOrbita() {
		return TiempOrbita;
	}
	public void setTiempOrbita(float tiempOrbita) {
		this.TiempOrbita = tiempOrbita;
	}

	@Override
	public String toString() {
		return "La Luna de nombre " + getNombre() + " que mide " + getDiametro() + " kms. de diámetro y el tiempo de órbita es de " + getTiempOrbita() + " días.";
	}

	//Metodo ToString.
	

	
	/*
	 * Cantidades de lunas por planetas:
● Mercurio: Ninguna.
● Venus: Ninguna.
● Tierra: 1.
● Marte: 2.
● Júpiter: Crear solo 2 de las 79
● Saturno: Crear solo 2 de las 82
● Urano: Crear solo 2 de las 27
● Neptuno: Crear solo 2 de las 14
*/
	
	
	
	
}
