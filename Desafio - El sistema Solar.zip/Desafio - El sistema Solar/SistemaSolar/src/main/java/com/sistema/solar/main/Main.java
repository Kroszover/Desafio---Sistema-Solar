/**
 * 
 */
package com.sistema.solar.main;

import com.sistema.solar.clases.SistemaSolar;
import com.sistema.solar.clases.Planeta;

import java.util.ArrayList;

import com.sistema.solar.clases.Luna;


/**
 *  * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SistemaSolar sistSolar = new SistemaSolar();
		ArrayList<Planeta> planetas = new ArrayList <Planeta> ();
		
		//A�adimos planetas (Tama�o, distancia al sol)
		//AddLuna (Diametro, Tiempo en Orbita)
		
		//Mercurio
		Planeta mercurio = new Planeta ("Mercurio", 4880, 57910000);
		
		//Venus
		Planeta venus = new Planeta ("Venus", 12104, 108200000);
		
		//Tierra
		Planeta tierra = new Planeta ("Tierra", 12756,149600000);
		tierra.addLuna(new Luna("Luna", 3476, 27322 ));
		
		//Marte con (f)toma los numeros decimales.
		Planeta marte = new Planeta ("Marte", 6794, 227940000);
		marte.addLuna(new Luna ("Phobos", 28*20, 0.319f));
		marte.addLuna(new Luna ("Deimos", 8, 1263));
		
		//Jupiter
		Planeta jupiter = new Planeta ("Jupiter", 142984, 77833000); //crear 2 de las 79 lunas
		jupiter.addLuna(new Luna ("Themisto",8 ,130 ));
		jupiter.addLuna(new Luna ("Kalyke", 5 ,760 ));
		
		//Saturno
		Planeta saturno = new Planeta ("Saturno", 108728, 1429400000); //crear 2 de las 82 lunas
		saturno.addLuna(new Luna ("Bestla",7 ,1083 ));
		saturno.addLuna(new Luna ("Fenrir",4 ,1260 ));
		
		//Urano
		Planeta urano = new Planeta ("Urano",51118 , 28709900*100 ); // crear 2 de las 27 lunas.
		urano.addLuna(new Luna ("Caliban", 80 , 579 ));
		urano.addLuna(new Luna ("Puck", 154 , 0.762f ));
		
		//Neptuno
		Planeta neptuno = new Planeta ("Neptuno" ,49532 , 45043000*100 ); // crear 2 de las 14 lunas.
		neptuno.addLuna(new Luna ("Nereid",340 , 360 ));
		neptuno.addLuna(new Luna ("Triton", 2705,5877 ));
		
		//A�adimos los planetas.
		planetas.add(mercurio);
		planetas.add(venus);
		planetas.add(tierra);
		planetas.add(marte);
		planetas.add(jupiter);
		planetas.add(saturno);
		planetas.add(urano);
		planetas.add(neptuno);
		
		//Seteamos los planetas.
		sistSolar.setPlanetas(planetas);
		//Mostramos la info de los planetas
		sistSolar.MostrarInfoPlanetas();
		System.out.println();
		//Mostramos info de los planetas con sus lunas. 
		sistSolar.MostrarInforPlanetasconsuslunas();

	}

}
