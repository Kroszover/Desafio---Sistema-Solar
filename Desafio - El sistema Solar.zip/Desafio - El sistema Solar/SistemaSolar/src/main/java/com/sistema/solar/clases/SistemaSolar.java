/**
 * 
 */
package com.sistema.solar.clases;

import java.util.ArrayList;

/**
 *  * * @author camilo Lavado
 * @date 22/03/2022
 * @version 1.0.0
 * @category Desafios.
 */
public class SistemaSolar{
	
	//Arraylist para los planetas.
	private ArrayList<Planeta> planetas = new ArrayList <Planeta>();

	//Constructores.
	public SistemaSolar(ArrayList<Planeta> planetas) {
		super();
		this.planetas = planetas;
	}

	public SistemaSolar() {

		
	}

	public ArrayList<Planeta> getPlanetas() {
		return planetas;
	}

	public void setPlanetas(ArrayList<Planeta> planetas) {
		this.planetas = planetas;
	}
	
	
	//Metodos.
	
	public void MostrarInfoPlanetas() {
		for (Planeta planeta : planetas) {
			System.out.println(planeta.toString());
		}
		
	}
	
	public void MostrarInforPlanetasconsuslunas () {
		for (Planeta planeta : planetas) {
			System.out.println(planeta.toString());
			for (Luna luna : planeta.getLunas()) {
				System.out.println(luna.toString());
			}
			System.out.println();
			
		}
	}
	
	
}


	/*
	public void MostrarInfoPlanetas() {
		System.out.println("Mostrar Informacion de los planetas.");
		//Apoyarse en el metodo ToString
}
	public void MostrarInforPlanetasconsuslunas() {
		System.out.println("Mostrar informacion de los planetas y de sus respectivas lunas.");
		//Apoyarse en el metodo ToString
	}*/
	
	
/*
 *3. Se requiere hacer que el sistema solar funcione, genere la clase del sistema solar llamada SistemaSolar donde inyecte los planetas apoy�ndose por un
ArrayList<Planeta>, desde aqu� genere dos m�todos, el primero debe mostrar la
informaci�n de los planetas y el segundo deber mostrar la informaci�n de los planetas y
de sus respectivas lunas. Ap�yese del m�todo toString en ambos casos. */
 